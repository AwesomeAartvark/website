 var jquery = require('jquery');
 var justifiedGallery = require('justifiedGallery');

 jquery("#simpletest").justifiedGallery();
cd ../../
browserify test/browserify/index.js -o test/browserify/dist/bundle.js
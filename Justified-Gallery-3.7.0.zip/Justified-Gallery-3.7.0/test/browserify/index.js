 var jquery = require('jquery');
 var justifiedGallery = require('../../dist/js/jquery.justifiedGallery.js')(jquery);

 jquery("#simpletest").justifiedGallery();